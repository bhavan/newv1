<?php
/**
* Author: Achim Raji - www.filmanleitungen.de
* JUGA - A Joomla User Group Access Component
* @package JUGA
* @license Komponent oparty o Licencj� GNU/GPL (zobacz LICENSE.php w g��wnym katalogu Joomla!)
* Wersja polska takcigoniepodam@interia.pl
**/

// ************************************************************************
/**
* ADMIN SIDE
*/
// ************************************************************************
// Sync
DEFINE("_juga_syncron_comps","Synchronizacja komponent�w...");
DEFINE("_juga_syncron_newcomps"," wpisy(-�w) nowych komponent�w - OK ");
DEFINE("_juga_syncron_content","Synchronizacja zawarto�ci...");
DEFINE("_juga_syncron_newcontent"," wpisy(-�w) nowej zawarto�ci - OK ");

DEFINE("_juga_syncron_users"," Synchronizacja u�ytkownik�w...");
DEFINE("_juga_syncron_newusers"," wpisy(-�w) nowych u�ytkownik�w - OK ");

//admin_juga_html.php
DEFINE("_juga_config","Konfiguracja");
DEFINE("_juga_config_assign_users","Przypisz u�ytkownik�w");
DEFINE("_juga_config_title","Tytu�");
DEFINE("_juga_config_desc","Opis");
DEFINE("_juga_config_value","Warto��");
DEFINE("_juga_config_edit","Edycja");
DEFINE("_juga_config_new","Nowy");
DEFINE("_juga_config_usergroups","Grupy u�ytkownik�w");
DEFINE("_juga_config_usergroup","Grupa u�ytkownika:");
DEFINE("_juga_config_user","U�ytkownik");
DEFINE("_juga_config_users","U�ytkownicy");
DEFINE("_juga_config_username","Nazwa u�ytkownika");
DEFINE("_juga_config_filter","Filtr:");
DEFINE("_juga_config_members","Cz�onkowie");
DEFINE("_juga_config_items","Elementy");
DEFINE("_juga_config_details","Detale");
DEFINE("_juga_config_siteitems","Elementy strony");
DEFINE("_juga_config_option","Opcja");
DEFINE("_juga_config_task","Zadanie");
DEFINE("_juga_config_typeid","Typ ID");
DEFINE("_juga_config_type","Typ");
DEFINE("_juga_config_errorurl","Adres url CE");
DEFINE("_juga_config_errorurl1","Obecny adres b��du (URL)");
DEFINE("_juga_config_currentgroups","Obecna Grupa(y)");
DEFINE("_juga_config_groups","Grupy");
DEFINE("_juga_config_groups_enroll","Zapisz");
DEFINE("_juga_config_groups_withdraw","Wycofaj");
DEFINE("_juga_config_publish","Opublikowane");
DEFINE("_juga_config_unpublish","Nieopublikowane");
// new in v0.2
DEFINE("_juga_config_define_access","Okre�l dost�p");
DEFINE("_juga_config_access","Dost�p");
DEFINE("_juga_config_current_flex_group","flex");
DEFINE("_juga_config_usergroup_id","ID Grupy");
DEFINE("_juga_config_joomlagroup","Grupy Joomla");
DEFINE("_juga_config_item","Obiekt");
DEFINE("_juga_config_switch","Prze��cz");
DEFINE("_juga_config_codes","Kod dost�pu");
DEFINE("_juga_config_codes_times","Dozwolony czas");
DEFINE("_juga_config_codes_hits","Wywo�ania");
DEFINE("_juga_config_codes_group","Grupa (ID#)");
DEFINE("_juga_config_codes_status","Status");
DEFINE("_juga_config_include","Zawiera");
DEFINE("_juga_config_exclude","Wyklucza ca�� opcj�");
DEFINE("_juga_config_errorurl_published","Opublikowa� adres CE URL?");
DEFINE("_juga_config_tools","Narz�dzia");
DEFINE("_juga_config_patch","Sprawd� instalacj� JUGA (v0.2)");

//toolbar_juga_html.php
DEFINE("_juga_config_publishce","Opublikuj CE");
DEFINE("_juga_config_defaultce","Domy�lne CE");
DEFINE("_juga_config_removece","Usu� CE");
DEFINE("_juga_config_sync","Synchronizuj");
DEFINE("_juga_config_default","Domy�lny");
DEFINE("_juga_config_close","Zamknij");
// new in v0.2
DEFINE("_juga_config_flexgroup","Flex +");
DEFINE("_juga_config_flexgroup_withdraw","Flex -");

// juga.class.php
DEFINE("_juga_title_exist","Tytu� ju� istnieje.");
DEFINE("_juga_title_blank","Musi mie� tytu�.");

DEFINE("_JUGA_ID", "ID");
DEFINE("_JUGA_VIEW", "Podgl�d");
DEFINE("_JUGA_NORECORDS", "Brak wpis�w");

// TIPS v1.0
DEFINE("_TIP_juga_config_codes_times", "Maksymalna ilo�� razy kiedy kod dost�pu mo�e zosta� u�yty. U�yj -1 dla nieograniczonej liczby.");
DEFINE("_TIP_juga_config_exclude", "Je�li ustawione na TAK, JUGA nie b�dzie narzuca� �adnych ogranicze� na t� opcj�  (com_whatever) i wszyscy u�ytkownicy b�d� mie� nieograniczony do niej dost�p.");
DEFINE("_TIP_juga_config_errorurl_published", "Je�li ustawiono TAK, JUGA przekieruje u�ytkownika do "._juga_config_errorurl1." (chyba �e ustawiono wcze�niej domy�ln� stron� b��du w Pliku JUGA - Konfiguracja) wtedy kiedy b�dzie pr�bowa� uzyska� dost�p do rzeczy o ograniczonym dost�pie."); 
DEFINE("_TIP_juga_config_errorurl1", "Je�li "._juga_config_errorurl_published." ustawiono na TAK, JUGA przekieruje u�ytkownika do tej strony (chyba �e domy�lny URL b��du zosta� zdefiniowany w JUGA - Konfiguracja), wtedy kiedy b�dzie pr�bowa� uzyska� dost�p do zabronionych rzeczy.");
DEFINE("_TIP_juga_config_typeid", "Wiele komponent�w, tak jak np. com_content (lub inne), u�ywa zmiennej id do identyfikacji element�w. Aby zabroni� dla okre�lonych element�w kt�re u�ywaj� zmiennej id, wpisz tutaj warto�� tych id. Aby zignorowa� zostaw puste lub wpisz 0.");
DEFINE("_TIP_juga_config_task", "Prawie wszystkie komponenty u�ywaj� zmiennych warto�ci zada� do identyfikacji akcji do wykonania. Aby zabroni� specyficznego zadania, wpisz warto�� zadania tutaj. Aby ignorowa� pozostaw puste.");
DEFINE("_TIP_JUGA_SECTION", "Wiele komponent�w, tak jak com_juga (oraz inne stworzone przez Dioscouri), u�ywaj� r�nych sekcji do identyfikacji podstawowych komend. Aby zabroni� specyficznej komendy kt�ra u�ywana jest przez zmienn� sekcji, wpisz tutaj id sekcji. Aby ignorowa� pozostaw puste.");
DEFINE("_TIP_juga_config_option", "Wszystkie komponenty identyfikuj� si� poprzez ich nazw� przy opcji (Tak jak: com_frontpage, com_remository, com_fireboard, lub com_cokolwiek). Wpisz tutaj t� nazw�, aby ustawi� prawa dost�pu JUGA.");
DEFINE("_TIP_juga_config_title", "Identyfikuje element tej strony � popularne warto�ci s� tytu�em strony (Tak jak np.: Witamy w Joomla!) lub nazw� komponentu (tak jak np.: Community Builder)."); //

// ************************************************************************

/** * FRONT END */ //

// ************************************************************************

//juga.php

DEFINE("_juga_invalid_code","Nieprawid�owy kod dost�pu.");
DEFINE("_juga_code_success","Kod dost�pu wygenerowany poprawnie."); //
juga.html.php
DEFINE("_juga_code","Kod dost�pu");