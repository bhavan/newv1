<?php 
/**
 * JEvents Component for Joomla 1.5.x
 *
 * @version     $Id: edit.php 1438 2009-05-02 09:25:42Z geraint $
 * @package     JEvents
 * @copyright   Copyright (C)  2008-2009 GWE Systems Ltd
 * @license     GNU/GPLv2, see http://www.gnu.org/licenses/gpl-2.0.html
 * @link        http://www.jevents.net
 */

defined('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();

if ($this->item->value=="" && file_exists(dirname(__FILE__).DS.$this->item->name.".html")) $this->item->value = file_get_contents(dirname(__FILE__).DS.$this->item->name.".html");
$this->replaceLabels($this->item->value);

?>		
<div id="jevents">
<form action="index.php" method="post" name="adminForm" >
<table width="90%" border="0" cellpadding="2" cellspacing="2" class="adminform">
<tr>
<td>
		<input type="hidden" name="name" value="<?php echo $this->item->name;?>">
		
		<script type="text/javascript" language="Javascript">
		function submitbutton(pressbutton) {
			var form = document.adminForm;
			<?php echo $editor->getContent( 'value' ); ?>
			submitform(pressbutton);
		}

		</script>
        <div class="adminform" align="left">
       	<div style="margin-bottom:20px;">
	        <table cellpadding="5" cellspacing="0" border="0" >
    			<tr>
                	<td align="left"><?php echo JText::_('TITLE'); ?>:</td>
                    <td colspan="2">
                    	<?php echo htmlspecialchars( $this->item->title, ENT_QUOTES, 'UTF-8'); ?>
                    	<!--<input class="inputbox" type="text" name="title" size="50" maxlength="100" value="<?php echo htmlspecialchars( $this->item->title, ENT_QUOTES, 'UTF-8'); ?>" />//-->
                    </td>
      			</tr>
    			<tr>
                	<td align="left"><?php echo JText::_('NAME'); ?>:</td>
                    <td colspan="2">
                    	<?php echo htmlspecialchars( $this->item->name, ENT_QUOTES, 'UTF-8'); ?>
                    </td>
      			</tr>
                 <tr>
                 	<td valign="top" align="left">
                    <?php echo JText::_('TEXT'); ?>
                    </td>
                    <td >
                    <?php
                    // parameters : areaname, content, hidden field, width, height, rows, cols
                    echo $editor->display( 'value',  htmlspecialchars( $this->item->value, ENT_QUOTES, 'UTF-8'), 600, 450, '70', '15', false) ;
                    ?>
                    </td>
                    <td valign="top">
                		<table cellpadding="0" cellspacing="0" border="0"><tr>
                		<td><?php echo JText::_("JEV_PLUGIN_INSTRUCTIONS",true);?></td>
                		<td><select id="jevdefaults" onchange="defaultsEditorPlugin.insert('value','jevdefaults' )" ></select></td>
                		</tr>
                		</table>

						<script type="text/javascript">
						defaultsEditorPlugin.node($('jevdefaults'),"<?php echo JText::_("JEV_PLUGIN_SELECT",true);?>","");
						// built in group
						var optgroup = defaultsEditorPlugin.optgroup($('jevdefaults') , "<?php echo JText::_("JEV_CORE_DATA",true);?>");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD TITLE",true);?>", "TITLE");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD ICALBUTTON",true);?>", "ICALBUTTON");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD EDITBUTTON",true);?>", "EDITBUTTON");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD REPEATSUMMARY",true);?>", "REPEATSUMMARY");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD PREVIOUSNEXT",true);?>", "PREVIOUSNEXT");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD CREATOR",true);?>", "CREATOR");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD HITS",true);?>", "HITS");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD DESCRIPTION",true);?>", "DESCRIPTION");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD LOCATION_LABEL",true);?>", "LOCATION_LABEL");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD LOCATION",true);?>", "LOCATION");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD CONTACT_LABEL",true);?>", "CONTACT_LABEL");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD CONTACT",true);?>", "CONTACT");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD EXTRAINFO",true);?>", "EXTRAINFO");
						defaultsEditorPlugin.node(optgroup , "<?php echo JText::_("JEV FIELD CATEGORY",true);?>", "CATEGORY");

						<?php
						// get list of enabled plugins
						$jevplugins = JPluginHelper::getPlugin("jevents");
						foreach ($jevplugins as $jevplugin){
							if (JPluginHelper::importPlugin("jevents", $jevplugin->name)){
								$classname = "plgJevents".ucfirst($jevplugin->name);
								if (is_callable(array($classname,"fieldNameArray"))){
									$lang = JFactory::getLanguage();
									$lang->load("plg_jevents_".$jevplugin->name,JPATH_ADMINISTRATOR);
									$fieldNameArray = call_user_func(array($classname,"fieldNameArray"));
									?>
									optgroup = defaultsEditorPlugin.optgroup($('jevdefaults') , '<?php echo $fieldNameArray["group"];?>');
									<?php
									for ($i=0;$i<count($fieldNameArray['labels']);$i++) {
										?>
										defaultsEditorPlugin.node(optgroup , "<?php echo $fieldNameArray['labels'][$i];?>", "<?php echo $fieldNameArray['values'][$i];?>");
										<?php
									}																		
								}
							}
						}
						?>
						</script>
                    
                    </td>
                 </tr>
            </table>
		</div>
		</div>




</td>
</tr>  
</table>
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="task" value="defaults.edit" />
<input type="hidden" name="act" value="" />
<input type="hidden" name="option" value="<?php echo JEV_COM_COMPONENT;?>" />
</form>
</div>