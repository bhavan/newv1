<?php 
defined('_JEXEC') or die('Restricted access');

include(JEV_VIEWS."/default/cat/tmpl/".basename(__FILE__));
